
import React,{useState,useEffect} from 'react';
function App() {
   const [data,setData] = useState([])
   useEffect(()=>{
    fetch("http://localhost:9192/getStudents")
    .then((result)=>{
      result.json().then((resp)=>{
        setData(resp);
      })
    })
   },[])

   console.warn(data);
  return (
   <div>
      <table border="1">
        <tr>
          <td>Id</td>
          <td>Name</td>
          <td>Age</td>
          <td>Gender</td>
        </tr>
         {
           data.map((item)=>
            <tr>
           <td>{item.id}</td>
          <td>{item.name}</td>
          <td>{item.age}</td>
          <td>{item.gender}</td>
          </tr>
           )
         }
      </table>
   </div>
  );
}

export default App;
