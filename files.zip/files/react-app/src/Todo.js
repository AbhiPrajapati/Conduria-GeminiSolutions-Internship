function Todo()
{
   return (
       <div >
      
        <div className="card">
          <h2 className="title">TITLE</h2>
          <div className="btn">
            <button >Delete</button>
          </div>
        </div>
    </div>
   );
}

export default Todo;